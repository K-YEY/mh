<script setup>
import { ref, onBeforeUnmount } from 'vue'
import { useForm, Link } from '@inertiajs/vue3'
import { useI18n } from '@/Composables/useI18n'
import { 
  ArrowLeft, 
  ArrowRight, 
  Camera, 
  UploadCloud, 
  FileText, 
  CheckCircle2, 
  AlertCircle, 
  Trash2, 
  X, 
  RefreshCw,
  Building2,
  Ship,
  ShieldCheck
} from 'lucide-vue-next'

const { isAr } = useI18n()

const props = defineProps({
  shipping_lines: Array,
  customs_brokers: Array,
  truckers: Array,
  ports: Array,
  coo_document_type: Object,
})

const form = useForm({
  direction: 'EXPORT',
  shipment_mode: 'FCL',
  shipping_line_id: '',
  customs_broker_id: '',
  trucker_id: '',
  booking_reference: '',
  master_bl_number: '',
  vessel_name: '',
  voyage_number: '',
  pol_id: '',
  pod_id: '',
  etd: '',
  eta: '',
  // Mandatory Certificate of Origin (COO) Details & Attachment
  coo_type: 'EUR.1',
  coo_reference_number: '',
  chamber_of_commerce: 'الغرفة التجارية المصرية',
  coo_issue_date: new Date().toISOString().slice(0, 10),
  coo_file: null,
  coo_scanned_data: null,
})

// Camera Scanner Modal State
const isScannerOpen = ref(false)
const scannerVideo = ref(null)
const scannerCanvas = ref(null)
const mediaStream = ref(null)
const scannerError = ref('')
const scannedPreviewUrl = ref(null)
const uploadedFileName = ref('')
const uploadedFileSize = ref('')

const openScanner = async () => {
  scannerError.value = ''
  isScannerOpen.value = true

  try {
    const stream = await navigator.mediaDevices.getUserMedia({
      video: {
        facingMode: { ideal: 'environment' },
        width: { ideal: 1920 },
        height: { ideal: 1080 },
      },
    })
    mediaStream.value = stream
    if (scannerVideo.value) {
      scannerVideo.value.srcObject = stream
    }
  } catch (err) {
    scannerError.value = isAr.value
      ? 'تعذر الوصول إلى الكاميرا. يرجى التأكد من إعطاء الصلاحية أو استخدام رفع ملف PDF.'
      : 'Could not access camera. Please allow camera access or upload a file directly.'
  }
}

const closeScanner = () => {
  if (mediaStream.value) {
    mediaStream.value.getTracks().forEach((track) => track.stop())
    mediaStream.value = null
  }
  isScannerOpen.value = false
}

const captureScan = () => {
  if (!scannerVideo.value) return

  const video = scannerVideo.value
  const canvas = scannerCanvas.value || document.createElement('canvas')
  canvas.width = video.videoWidth || 1280
  canvas.height = video.videoHeight || 720

  const ctx = canvas.getContext('2d')
  ctx.drawImage(video, 0, 0, canvas.width, canvas.height)

  const dataUrl = canvas.toDataURL('image/jpeg', 0.92)
  form.coo_scanned_data = dataUrl
  form.coo_file = null
  scannedPreviewUrl.value = dataUrl
  uploadedFileName.value = `Scanned_COO_${new Date().getTime()}.jpg`
  uploadedFileSize.value = `${Math.round((dataUrl.length * 0.75) / 1024)} KB`

  closeScanner()
}

const handleFileUpload = (event) => {
  const file = event.target.files[0]
  if (file) {
    form.coo_file = file
    form.coo_scanned_data = null
    uploadedFileName.value = file.name
    uploadedFileSize.value = `${(file.size / 1024).toFixed(1)} KB`

    if (file.type.startsWith('image/')) {
      scannedPreviewUrl.value = URL.createObjectURL(file)
    } else {
      scannedPreviewUrl.value = null
    }
  }
}

const removeAttachment = () => {
  form.coo_file = null
  form.coo_scanned_data = null
  scannedPreviewUrl.value = null
  uploadedFileName.value = ''
  uploadedFileSize.value = ''
}

onBeforeUnmount(() => {
  if (mediaStream.value) {
    mediaStream.value.getTracks().forEach((track) => track.stop())
  }
})

const submit = () => {
  form.post(route('master-shipments.store'), {
    forceFormData: true,
  })
}
</script>

<template>
  <div class="max-w-5xl mx-auto space-y-6 pb-12">
    <!-- Header -->
    <div class="flex items-center gap-3">
      <Link 
        :href="route('master-shipments.index')" 
        class="p-2 rounded-lg bg-zinc-100 text-zinc-600 hover:text-zinc-950 border border-zinc-200 transition-colors"
      >
        <component :is="isAr ? ArrowRight : ArrowLeft" class="w-4 h-4" />
      </Link>
      <div>
        <div class="flex items-center gap-2">
          <Ship class="w-5 h-5 text-zinc-950" />
          <h1 class="text-xl font-extrabold text-zinc-950 tracking-tight">
            {{ isAr ? 'فتح ملف شحنة بحرية ماستر جديد' : 'Open New Master Ocean Shipment' }}
          </h1>
        </div>
        <p class="text-xs text-zinc-500">
          {{ isAr ? 'تسجيل حجز البوليصة الرئيسية MBL مع فحص المستندات وشهادة المنشأ وربط المخلص والناقل' : 'Initialize Master Bill of Lading (MBL), Carrier Haulage, Customs Broker & Mandatory COO Scan' }}
        </p>
      </div>
    </div>

    <!-- Error Alert if COO or other errors exist -->
    <div v-if="Object.keys(form.errors).length > 0" class="p-4 rounded-xl bg-red-50 border border-red-200 text-red-700 text-xs flex items-start gap-3">
      <AlertCircle class="w-5 h-5 text-red-600 shrink-0 mt-0.5" />
      <div>
        <div class="font-bold mb-1">{{ isAr ? 'يرجى مراجعة الأخطاء التالية:' : 'Please correct the following errors:' }}</div>
        <ul class="list-disc list-inside space-y-1 font-sans">
          <li v-for="(err, field) in form.errors" :key="field">{{ err }}</li>
        </ul>
      </div>
    </div>

    <form @submit.prevent="submit" class="space-y-6">
      <!-- 1. الأساسيات والخط الملاحي -->
      <div class="shadcn-card p-6 space-y-4">
        <div class="flex items-center gap-2 border-b border-zinc-100 pb-3">
          <Ship class="w-4 h-4 text-zinc-950" />
          <h2 class="text-sm font-bold text-zinc-950 uppercase tracking-wide">
            {{ isAr ? '1. بيانات الرحلة والخط الملاحي (Carrier & Voyage)' : '1. Carrier & Voyage Data' }}
          </h2>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
          <!-- Direction -->
          <div>
            <label class="block text-xs font-bold text-zinc-800 mb-1">{{ isAr ? 'اتجاه الشحن' : 'Trade Direction' }}</label>
            <select v-model="form.direction" class="shadcn-input">
              <option value="EXPORT">{{ isAr ? 'صادر حاصلات زراعية (EXPORT)' : 'Agri Export' }}</option>
              <option value="IMPORT">{{ isAr ? 'وارد (IMPORT)' : 'Import' }}</option>
            </select>
          </div>

          <!-- Mode -->
          <div>
            <label class="block text-xs font-bold text-zinc-800 mb-1">{{ isAr ? 'نوع نمط الشحن' : 'Shipment Mode' }}</label>
            <select v-model="form.shipment_mode" class="shadcn-input">
              <option value="FCL">{{ isAr ? 'FCL (حاوية كاملة مبردة / جافة)' : 'FCL (Full Container Load)' }}</option>
              <option value="LCL">{{ isAr ? 'LCL (مجمع جزئي)' : 'LCL (Consolidated Groupage)' }}</option>
            </select>
          </div>

          <!-- Shipping Line -->
          <div>
            <label class="block text-xs font-bold text-zinc-800 mb-1">
              {{ isAr ? 'الناقل البحري / الخط الملاحي' : 'Ocean Carrier / Line' }}
              <span class="text-red-500">*</span>
            </label>
            <select v-model="form.shipping_line_id" class="shadcn-input" required>
              <option value="" disabled>{{ isAr ? 'اختر الخط الملاحي...' : 'Select Carrier Line...' }}</option>
              <option v-for="line in shipping_lines" :key="line.id" :value="line.id">
                {{ line.legal_name }} ({{ line.code }})
              </option>
            </select>
          </div>

          <!-- Booking Ref -->
          <div>
            <label class="block text-xs font-bold text-zinc-800 mb-1">{{ isAr ? 'رقم مرجع الحجز (Booking Ref)' : 'Booking Reference #' }}</label>
            <input v-model="form.booking_reference" type="text" placeholder="e.g. MSK-8890123" class="shadcn-input font-mono" dir="ltr" />
          </div>

          <!-- Vessel Name -->
          <div>
            <label class="block text-xs font-bold text-zinc-800 mb-1">
              {{ isAr ? 'اسم السفينة' : 'Vessel Name' }}
              <span class="text-red-500">*</span>
            </label>
            <input v-model="form.vessel_name" type="text" placeholder="e.g. MAERSK MC-KINNEY" class="shadcn-input font-mono" required dir="ltr" />
          </div>

          <!-- Voyage # -->
          <div>
            <label class="block text-xs font-bold text-zinc-800 mb-1">
              {{ isAr ? 'رقم الرحلة البحرية' : 'Voyage Number' }}
              <span class="text-red-500">*</span>
            </label>
            <input v-model="form.voyage_number" type="text" placeholder="e.g. 2604-W" class="shadcn-input font-mono" required dir="ltr" />
          </div>

          <!-- POL -->
          <div>
            <label class="block text-xs font-bold text-zinc-800 mb-1">
              {{ isAr ? 'ميناء القيام / الشحن (POL)' : 'Port of Loading (POL)' }}
              <span class="text-red-500">*</span>
            </label>
            <select v-model="form.pol_id" class="shadcn-input" required>
              <option value="" disabled>{{ isAr ? 'اختر ميناء الشحن...' : 'Select POL...' }}</option>
              <option v-for="p in ports" :key="p.id" :value="p.id">
                {{ p.name }} ({{ p.code }})
              </option>
            </select>
          </div>

          <!-- POD -->
          <div>
            <label class="block text-xs font-bold text-zinc-800 mb-1">
              {{ isAr ? 'ميناء الوصول / التفريغ (POD)' : 'Port of Discharge (POD)' }}
              <span class="text-red-500">*</span>
            </label>
            <select v-model="form.pod_id" class="shadcn-input" required>
              <option value="" disabled>{{ isAr ? 'اختر ميناء الوصول...' : 'Select POD...' }}</option>
              <option v-for="p in ports" :key="p.id" :value="p.id">
                {{ p.name }} ({{ p.code }})
              </option>
            </select>
          </div>

          <!-- Master B/L (Optional at booking) -->
          <div>
            <label class="block text-xs font-bold text-zinc-800 mb-1">{{ isAr ? 'رقم بوليصة الشحن الماستر (MBL #)' : 'Master B/L #' }}</label>
            <input v-model="form.master_bl_number" type="text" placeholder="e.g. MAEU9812903" class="shadcn-input font-mono" dir="ltr" />
          </div>

          <!-- ETD -->
          <div>
            <label class="block text-xs font-bold text-zinc-800 mb-1">
              {{ isAr ? 'التاريخ المتوقع للمغادرة (ETD)' : 'Estimated Departure (ETD)' }}
              <span class="text-red-500">*</span>
            </label>
            <input v-model="form.etd" type="date" class="shadcn-input font-mono" required dir="ltr" />
          </div>

          <!-- ETA -->
          <div>
            <label class="block text-xs font-bold text-zinc-800 mb-1">
              {{ isAr ? 'التاريخ المتوقع للوصول (ETA)' : 'Estimated Arrival (ETA)' }}
              <span class="text-red-500">*</span>
            </label>
            <input v-model="form.eta" type="date" class="shadcn-input font-mono" required dir="ltr" />
          </div>
        </div>
      </div>

      <!-- 2. المخلص الجمركي وشركة النقل البري (Customs Broker & Inland Haulage) -->
      <div class="shadcn-card p-6 space-y-4">
        <div class="flex items-center justify-between border-b border-zinc-100 pb-3">
          <div class="flex items-center gap-2">
            <Building2 class="w-4 h-4 text-zinc-950" />
            <h2 class="text-sm font-bold text-zinc-950 uppercase tracking-wide">
              {{ isAr ? '2. المخلص الجمركي وشركة النقل البري / المبرد' : '2. Customs Broker & Inland Trucker' }}
            </h2>
          </div>
          <Link 
            :href="route('parties.index')" 
            target="_blank"
            class="text-[11px] text-zinc-600 hover:text-zinc-950 underline flex items-center gap-1 font-sans"
          >
            <span>{{ isAr ? 'إدارة البروكرز وشركات النقل' : 'Manage Brokers & Truckers' }}</span>
          </Link>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
          <!-- Customs Broker Selection -->
          <div>
            <label class="block text-xs font-bold text-zinc-800 mb-1 flex items-center justify-between">
              <span>{{ isAr ? 'المخلص الجمركي (البروكر المعتمد للملف)' : 'Customs Broker' }}</span>
              <span class="text-[10px] text-zinc-500">{{ isAr ? '(اختياري)' : '(Optional)' }}</span>
            </label>
            <select v-model="form.customs_broker_id" class="shadcn-input">
              <option value="">{{ isAr ? '-- بدون مخلص جمركي محدد حالياً --' : '-- No Customs Broker Assigned --' }}</option>
              <option v-for="b in customs_brokers" :key="b.id" :value="b.id">
                {{ b.legal_name }} ({{ b.code }}) {{ b.tax_number ? ` - ضريبي: ${b.tax_number}` : '' }}
              </option>
            </select>
            <p class="text-[10px] text-zinc-500 mt-1">
              {{ isAr ? 'يمكنك اختيار المخلص الجمركي المسؤول عن إنهاء إجراءات الفحص والإفراج بالميناء' : 'Select customs broker handling port inspection and clearance.' }}
            </p>
          </div>

          <!-- Trucker / Inland Reefer Haulage -->
          <div>
            <label class="block text-xs font-bold text-zinc-800 mb-1 flex items-center justify-between">
              <span>{{ isAr ? 'شركة النقل البري / المبرد (Trucker Carrier)' : 'Inland Trucker / Reefer Haulier' }}</span>
              <span class="text-[10px] text-zinc-500">{{ isAr ? '(اختياري)' : '(Optional)' }}</span>
            </label>
            <select v-model="form.trucker_id" class="shadcn-input">
              <option value="">{{ isAr ? '-- بدون ناقل بري محدد حالياً --' : '-- No Trucking Company Assigned --' }}</option>
              <option v-for="t in truckers" :key="t.id" :value="t.id">
                {{ t.legal_name }} ({{ t.code }}) {{ t.phone ? ` - هاتف: ${t.phone}` : '' }}
              </option>
            </select>
            <p class="text-[10px] text-zinc-500 mt-1">
              {{ isAr ? 'شركة النقل المسؤولة عن نقل الحاويات المبردة من محطة التعبئة إلى رصيف الميناء' : 'Carrier responsible for transporting reefers from packhouse to ocean terminal.' }}
            </p>
          </div>
        </div>
      </div>

      <!-- 3. شهادة المنشأ الرسمية وأداة المسح الضوئي (Mandatory Certificate of Origin & Scanner) -->
      <div class="shadcn-card p-6 space-y-4 border-2 border-zinc-950/20 bg-zinc-50/50">
        <div class="flex items-center justify-between border-b border-zinc-200 pb-3">
          <div class="flex items-center gap-2">
            <ShieldCheck class="w-5 h-5 text-zinc-950" />
            <div>
              <h2 class="text-sm font-extrabold text-zinc-950 uppercase tracking-wide">
                {{ isAr ? '3. شهادة المنشأ الرسمية والمستند الإلزامي (Certificate of Origin)' : '3. Mandatory Certificate of Origin (COO)' }}
              </h2>
              <span class="text-[10px] text-zinc-500 font-mono">
                {{ isAr ? 'شرط إلزامي لإنشاء الشحنة (Scan or PDF Required)' : 'Mandatory Compliance requirement for Master Shipment initialization' }}
              </span>
            </div>
          </div>
          <span class="px-2.5 py-1 rounded text-[10px] font-mono font-bold uppercase bg-zinc-950 text-white">
            {{ isAr ? 'إلزامي للإنشاء' : 'REQUIRED' }}
          </span>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-4 gap-4">
          <!-- COO Type -->
          <div>
            <label class="block text-xs font-bold text-zinc-800 mb-1">
              {{ isAr ? 'نوع شهادة المنشأ' : 'Origin Cert Type' }}
              <span class="text-red-500">*</span>
            </label>
            <select v-model="form.coo_type" class="shadcn-input font-bold" required>
              <option value="EUR.1">{{ isAr ? 'يورو 1 (EUR.1 - الاتحاد الأوروبي)' : 'EUR.1 (European Union)' }}</option>
              <option value="AGADIR">{{ isAr ? 'اتفاقية أغادير (Agadir Agreement)' : 'Agadir Agreement' }}</option>
              <option value="GAFTA">{{ isAr ? 'اتفاقية التيسير العربية (GAFTA)' : 'GAFTA (Arab Trade)' }}</option>
              <option value="COMESA">{{ isAr ? 'الكوميسا (COMESA - السوق الأفريقي)' : 'COMESA' }}</option>
              <option value="GENERAL">{{ isAr ? 'شهادة منشأ عامة (General COO)' : 'General Certificate' }}</option>
            </select>
          </div>

          <!-- Reference Number -->
          <div>
            <label class="block text-xs font-bold text-zinc-800 mb-1">
              {{ isAr ? 'رقم اعتماد / مسلسل الشهادة' : 'COO Reference #' }}
              <span class="text-red-500">*</span>
            </label>
            <input 
              v-model="form.coo_reference_number" 
              type="text" 
              placeholder="e.g. EG-COO-2026-9901" 
              class="shadcn-input font-mono" 
              required 
              dir="ltr" 
            />
          </div>

          <!-- Chamber of Commerce -->
          <div>
            <label class="block text-xs font-bold text-zinc-800 mb-1">
              {{ isAr ? 'الغرفة التجارية المصدرة' : 'Chamber of Commerce' }}
            </label>
            <input 
              v-model="form.chamber_of_commerce" 
              type="text" 
              placeholder="e.g. الغرفة التجارية بالإسكندرية" 
              class="shadcn-input" 
            />
          </div>

          <!-- Issue Date -->
          <div>
            <label class="block text-xs font-bold text-zinc-800 mb-1">
              {{ isAr ? 'تاريخ الإصدار' : 'Issue Date' }}
            </label>
            <input 
              v-model="form.coo_issue_date" 
              type="date" 
              class="shadcn-input font-mono" 
              dir="ltr" 
            />
          </div>
        </div>

        <!-- Uploader & Scanner Action Box -->
        <div class="mt-4 pt-4 border-t border-zinc-200">
          <div class="flex items-center justify-between mb-3">
            <span class="text-xs font-bold text-zinc-950">
              {{ isAr ? 'إرفاق أو مسح أصل شهادة المنشأ (سحب PDF أو فحص ضوئي فوري):' : 'Upload or Scan Physical Certificate of Origin:' }}
            </span>
            <div class="flex items-center gap-2">
              <button 
                type="button" 
                @click="openScanner"
                class="px-3 py-1.5 rounded-lg bg-zinc-950 text-white hover:bg-zinc-800 transition-colors text-xs font-bold flex items-center gap-1.5 cursor-pointer shadow-xs"
              >
                <Camera class="w-4 h-4" />
                <span>{{ isAr ? 'مسح ضوئي بالكاميرا / الماسح' : 'Live Camera Scan' }}</span>
              </button>
            </div>
          </div>

          <!-- Upload Dropzone / Attached Card -->
          <div 
            v-if="!uploadedFileName" 
            class="border-2 border-dashed border-zinc-300 hover:border-zinc-500 rounded-xl p-6 text-center bg-white transition-all"
          >
            <input 
              type="file" 
              id="cooFileInput" 
              accept=".pdf,image/png,image/jpeg,image/jpg" 
              class="hidden" 
              @change="handleFileUpload" 
            />
            <label for="cooFileInput" class="cursor-pointer block space-y-2">
              <UploadCloud class="w-8 h-8 text-zinc-400 mx-auto" />
              <div class="text-xs font-bold text-zinc-800">
                {{ isAr ? 'اضغط لاختيار ملف شهادة المنشأ (PDF أو صورة) أو اسحبه هنا' : 'Click to select Certificate of Origin (PDF or Image) or drag & drop' }}
              </div>
              <div class="text-[10px] text-zinc-500">
                PDF, PNG, JPG (Max 20MB)
              </div>
            </label>
          </div>

          <!-- Attached Document Preview Card -->
          <div v-else class="p-4 rounded-xl bg-white border border-zinc-200 flex items-center justify-between shadow-xs">
            <div class="flex items-center gap-3">
              <div class="w-12 h-12 rounded-lg bg-zinc-100 border border-zinc-200 flex items-center justify-center overflow-hidden shrink-0">
                <img v-if="scannedPreviewUrl" :src="scannedPreviewUrl" alt="COO Preview" class="w-full h-full object-cover" />
                <FileText v-else class="w-6 h-6 text-zinc-700" />
              </div>
              <div>
                <div class="flex items-center gap-2">
                  <span class="text-xs font-bold text-zinc-950 font-mono">{{ uploadedFileName }}</span>
                  <span class="px-2 py-0.5 rounded text-[9px] font-mono font-bold bg-emerald-100 text-emerald-800 flex items-center gap-1">
                    <CheckCircle2 class="w-3 h-3" />
                    {{ isAr ? 'تم الإرفاق' : 'Attached' }}
                  </span>
                </div>
                <div class="text-[11px] text-zinc-500 font-mono mt-0.5">
                  {{ uploadedFileSize }} • {{ form.coo_scanned_data ? (isAr ? 'مسح ضوئي بالكاميرا' : 'Live Camera Scan') : (isAr ? 'ملف مرفوع' : 'Uploaded File') }}
                </div>
              </div>
            </div>

            <div class="flex items-center gap-2">
              <button 
                type="button" 
                @click="openScanner" 
                class="p-2 text-zinc-600 hover:text-zinc-950 rounded-lg hover:bg-zinc-100 text-xs font-bold transition-colors cursor-pointer"
                :title="isAr ? 'إعادة المسح' : 'Rescan'"
              >
                <RefreshCw class="w-4 h-4" />
              </button>
              <button 
                type="button" 
                @click="removeAttachment" 
                class="p-2 text-red-600 hover:text-red-700 rounded-lg hover:bg-red-50 text-xs font-bold transition-colors cursor-pointer"
                :title="isAr ? 'حذف المرفق' : 'Remove'"
              >
                <Trash2 class="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      </div>

      <!-- Action Footer -->
      <div class="flex items-center justify-between pt-4 border-t border-zinc-200">
        <div class="text-xs text-zinc-500">
          {{ isAr ? '* الحقول المؤشرة بعلامة حمراء وشهادة المنشأ إلزامية لتأسيس الشحنة الماستر.' : '* Marked fields and Certificate of Origin are required.' }}
        </div>

        <button 
          type="submit" 
          :disabled="form.processing" 
          class="shadcn-btn-primary px-8 py-2.5 font-bold cursor-pointer flex items-center gap-2 text-sm shadow-sm"
        >
          <Ship class="w-4 h-4" />
          <span>{{ isAr ? 'تأسيس وحفظ ملف الشحنة الماستر' : 'Initialize Ocean Master File' }}</span>
        </button>
      </div>
    </form>

    <!-- Interactive Camera Scanner Modal -->
    <div v-if="isScannerOpen" class="fixed inset-0 bg-black/80 z-50 flex items-center justify-center p-4 backdrop-blur-xs">
      <div class="bg-zinc-950 text-white rounded-2xl max-w-2xl w-full overflow-hidden border border-zinc-800 shadow-2xl flex flex-col">
        <!-- Modal Header -->
        <div class="p-4 border-b border-zinc-800 flex items-center justify-between">
          <div class="flex items-center gap-2">
            <Camera class="w-5 h-5 text-emerald-400" />
            <h3 class="font-bold text-sm">
              {{ isAr ? 'المسح الضوئي لشهادة المنشأ (Document Scanner)' : 'Live Document Scanner' }}
            </h3>
          </div>
          <button @click="closeScanner" class="text-zinc-400 hover:text-white p-1 rounded-lg">
            <X class="w-5 h-5" />
          </button>
        </div>

        <!-- Video Viewport / Viewfinder -->
        <div class="relative bg-black flex items-center justify-center min-h-[380px] overflow-hidden">
          <video 
            ref="scannerVideo" 
            autoplay 
            playsinline 
            class="w-full max-h-[460px] object-contain"
          ></video>

          <!-- Document Framing Overlay Guide -->
          <div class="absolute inset-8 border-2 border-emerald-400/80 rounded-xl pointer-events-none flex flex-col justify-between p-3">
            <div class="flex justify-between">
              <div class="w-4 h-4 border-t-2 border-l-2 border-emerald-400"></div>
              <div class="w-4 h-4 border-t-2 border-r-2 border-emerald-400"></div>
            </div>
            <div class="text-center bg-black/60 px-3 py-1 rounded-full self-center text-[11px] font-mono text-emerald-300">
              {{ isAr ? 'ضع شهادة المنشأ داخل الإطار واضغط على التقاط' : 'Align Document inside frame and click capture' }}
            </div>
            <div class="flex justify-between">
              <div class="w-4 h-4 border-b-2 border-l-2 border-emerald-400"></div>
              <div class="w-4 h-4 border-b-2 border-r-2 border-emerald-400"></div>
            </div>
          </div>

          <div v-if="scannerError" class="absolute inset-0 bg-zinc-900/95 flex items-center justify-center p-6 text-center text-red-400 text-xs">
            <div>
              <AlertCircle class="w-8 h-8 mx-auto mb-2 text-red-400" />
              {{ scannerError }}
            </div>
          </div>
        </div>

        <!-- Hidden Canvas for frame snapshot -->
        <canvas ref="scannerCanvas" class="hidden"></canvas>

        <!-- Modal Controls -->
        <div class="p-4 bg-zinc-900 border-t border-zinc-800 flex items-center justify-between">
          <button 
            type="button" 
            @click="closeScanner" 
            class="px-4 py-2 rounded-lg text-xs font-bold text-zinc-300 hover:text-white bg-zinc-800 hover:bg-zinc-700 transition-colors"
          >
            {{ isAr ? 'إلغاء' : 'Cancel' }}
          </button>

          <button 
            type="button" 
            @click="captureScan" 
            :disabled="!!scannerError"
            class="px-6 py-2.5 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-zinc-950 text-xs font-extrabold flex items-center gap-2 cursor-pointer shadow-lg transition-all"
          >
            <Camera class="w-4 h-4" />
            <span>{{ isAr ? 'التقاط وحفظ الصورة (Capture Scan)' : 'Capture Document' }}</span>
          </button>
        </div>
      </div>
    </div>
  </div>
</template>
